%computing error depends on epochs

clear all;
close all ;

p = 10; % samples
pp =9 ; % view point 
folder_set = {'011', '016', '021', '022', '033', '036', '038', '053', '059', '092'};
 
count =1;   
values=[];
objects=[];
view=[];  

mainpath ='/research2/ECCV_journal/multi_freq/L2ang_ei/standard/Deconv_L1_result/0422_32';
%epoch ='DCGAN.model-28000'%17206 25809 34412 43015 51618 60221 68824;
Lights = 12 % number of lighting source

suboutputpath ='output/save';
normalpath = '/research2/IR_normal_small/save'; 
maskpath = '/research2/IR_normal_small/mask';
fileID = fopen(sprintf('~/Dropbox/ECCV_result/multi_freq/Light/0422_nondetail_L2ang_ei.csv'),'w');
fprintf(fileID,'epoch,Light,mean_error,median_error,mean_angle_error,median_angle_error,10deg,15deg,20deg\n');
epochs = dir(fullfile(mainpath));

for epoch =3:length(epochs)
       
        for Light=1:Lights
             aloss_total = 0;
            aloss_total2 = 0;
            err_total = 0;
            err_total2 = 0;
            min_aloss = 100.0;
            max_aloss = -100.0;
            good_pixel1 = 10;
            good_pixel2 = 15;
            good_pixel3 = 20;
            A1_total = 0;
            A2_total = 0;
            A3_total = 0;
        for i = 1: pp %tilts
           
            
            fprintf('processing epoch %d Light %d object %d \n',epoch,Light,i);
            for j=1:p % objects
                
                N_ = dir(fullfile(sprintf('%s/%s/%s/%d',mainpath,epochs(epoch).name,folder_set{j},i),'single_normal_*.bmp'));
                im2 = im2double(imread(fullfile(sprintf('%s/%s/%s/%d',mainpath,epochs(epoch).name,folder_set{j},i),N_(Light).name)));
                
                im1 = im2double(imread(sprintf('%s%s%s%d%s%s',normalpath,folder_set{j},'/',i,'/','12_Normal.bmp')));
                im1 = imresize(im1,0.5);
                
                mask = imread(sprintf('%s%s%s%s%d%s',maskpath,'/',folder_set{j},'/',i,'/mask.bmp'));
                mask = imresize(mask,0.5);
                %se = strel('line',60,400);
                %mask = imerode(mask,se);
                n = sum(sum(mask));
                
                im1 = im1.*2-1;
                im2 = im2.*2-1;
                
                
                %%%% Mean Error%%%%%
                im1_ = im1.*repmat(mask,1,1,3);
                im2_ = im2.*repmat(mask,1,1,3);
                err = im1_ - im2_;
                err = abs(err);
                err = err.*double(repmat(mask,1,1,3));
                err_mean = sum(sum(sum(err)));
                err_mean = err_mean./n./3;
                
                err_total = err_total+err_mean;
                
                %%%% Median Error%%%%%
                tmp = err(err~=0);
                err_median = median(tmp);
                err_total2 = err_total2 + err_median;
                
                %%%% Angular Error %%%%
                
                r = size(im1,1);    c = size(im1,2);
                im1_ = im1;
                im2_ = im2;
                
                im1_v = reshape(im1_,[r*c,3]);
                im2_v = reshape(im2_,[r*c,3]);
                
                norm1 = sqrt ( im1_v(:,1).^2 + im1_v(:,2).^2+im1_v(:,3).^2 );
                norm2 = sqrt ( im2_v(:,1).^2 + im2_v(:,2).^2+im2_v(:,3).^2 );
                norm1_3 = repmat(norm1,1,3);
                norm2_3 = repmat(norm2,1,3);
                
                im1_vn = im1_v./norm1_3;
                im2_vn = im2_v./norm2_3;
                
                ang = im1_vn'.*im2_vn';
                ang = sum(ang);
                ang_ = reshape(ang',r,c);
                ang_m = ang_.*double(mask);
                %%%% Convert to radian angles
                
                ang_rad = acosd(ang_m);
                se = strel('line',60,400);
                mask = imerode(mask,se);
                ang_rad_m = ang_rad.*double(mask);
                
                
                ang_rad_m(find(ang_rad_m>30))=30;
                %             imagesc(ang_rad_m);
                %             colorbar
                %             colormap( 'jet' )
                %filename = sprintf('%s%s%d%s%s%s.bmp',folder,'/',j,'/','error_',type);
                
                aloss = sum(ang_rad_m(:))./sum(mask(:));
                aloss_total = aloss_total+aloss;
                tmp2 = ang_rad_m(ang_rad_m~=0);
                aloss_median = median(tmp2);
                aloss_total2 = aloss_total2 + aloss_median;
                
                A1 = length(find(tmp2<good_pixel1)) ./ length(tmp2) * 100;
                A2 = length(find(tmp2<good_pixel2)) ./ length(tmp2) * 100;
                A3 = length(find(tmp2<good_pixel3)) ./ length(tmp2) * 100;
                
                A1_total = A1_total+A1;
                A2_total = A2_total+A2;
                A3_total = A3_total+A3;
                
                values(count)= aloss;
                objects(count) = i;
                view(count) = j;
                count = count+1;
            end
        end
            err_total_mean = err_total/(p*pp);
         err_total_median = err_total2/(p*pp);
        aloss_total_mean = aloss_total/(p*pp);
        aloss_total_median = aloss_total2/(p*pp);
        A1_total_mean = A1_total/(p*pp);
        A2_total_mean = A2_total/(p*pp);
        A3_total_mean = A3_total/(p*pp);
        fprintf(fileID,'%d, %d,%.6f, %.6f,%.6f, %.6f,%.6f,%.6f,%.6f\n',epoch,Light,err_total_mean,err_total_median,aloss_total_mean,aloss_total_median,A1_total_mean,A2_total_mean,A3_total_mean);
        end
        
        
end
fclose('all');
