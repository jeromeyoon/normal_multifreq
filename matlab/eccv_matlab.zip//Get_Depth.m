%%%%% Estimate 3D mesh shape for all light directions and tilt angles

s = 0.5;
pp = 9;
folder_set = {'011', '016', '021', '022', '033', '036', '038', '053', '059', '092'};
savetype = '.bmp';

%mainpath = '/research2/ECCV_journal/deconv/NIR_single_3output/Deconv_L1_result';
mainpath = '/research2/ECCV_journal/deconv/resnet-tf2/resi_ad_result';
%GTpath = '/research2/ECCV_dataset_resized/';
GTpath = '/research2/IR_normal_small/';
%maskpath = '/research2/ECCV_dataset_resized';
savepath = '/home/yjyoon/Dropbox/ECCV_result/3D/0115_res/';
epoch ='0115/Res_DCGAN-853430';
%epoch ='DCGAN.model-33000';
if ~isdir(savepath)
    mkdir(savepath)
end

for i = 1: 10 %objects
    for j=5:5 % tilt angle
            N_ = dir(fullfile(sprintf('%s/%s/%s/%d',mainpath,epoch,folder_set{i},j),'single_*.bmp'));
            %N_ = dir(fullfile(sprintf('%s/%s/%d/%s/%s',mainpath,folder_set{i},j,epoch),'single_*.bmp'));
        for l=1:1
            fprintf('processing tilt angle %d/%d object %d/%d light %d/d%\n',j,9,i,10,l,12);
            
            %N = im2double(imread(fullfile(sprintf('%s/%s/%d/%s/%s',mainpath,folder_set{i},j,epoch),N_(l).name)));        
            N = im2double(imread(fullfile(sprintf('%s/%s/%s/%d',mainpath,epoch,folder_set{i},j),N_(l).name)));        
            N = N.*2 -1;
            
            %im = im2double(imread(fullfile(sprintf('%s/%s/%d/%s/%s',mainpath,folder_set{i},j,epoch),N_(l).name)));
            im = im2double(imread(fullfile(sprintf('%s/%s/%s/%d',mainpath,epoch,folder_set{i},j),N_(l).name)));
            im = im(:,:,1);
            
            % load mask image
            im_mask = imread(fullfile(GTpath,sprintf('%s%s/%d/%d.bmp','save',folder_set{i},j,l+4)));
            im_mask = imresize(im_mask,s);
            im_mask = logical(im_mask);
            idx = find(im_mask==1);
            im_mask = repmat(im_mask,[1,1,3]);
            
            N(im_mask==0) = 0;
            
            %%%%%% Invert normal to depth %%%%%%%%%%%%%%
            
            height = size(im,1);
            width = size(im,2);
            
            N = reshape(N,[height,width,3]);
            [x,y] = meshgrid(1:width,1:height);
            % figure
            u = N(:,:,1);
            v = N(:,:,2);
            y = flipud(y);
            v = flipud(v);
            % quiver(x,y,u,v)
            
            [X, Y, Z]=Depth_still(N,im_mask,height,width,3);
            
            Z = flipud(Z);        
            K = [2.99e+03*s, 0, 7.99e+02*s ; 0, 2.99e+03*s, 5.99e+02*s ; 0,0,1];
            
            im_mask =im_mask(:,:,1);
            im_mask = flipud(im_mask);
            grid = logical(im_mask(:,:,1));
            vertex = genVertex (Z,grid,K);
            
            C = im2uint8(im);
            C = double(C);
            C= round(C);
            C = repmat(C,[1,1,3]);
            C = reshape(C,[height*width,3]);
            
            id = find(grid~=0);
            R = C(:,1);   G = C(:,2);   B = C(:,3);
            C_R=R(id);  C_G=G(id);  C_B=B(id);
            C_ = [C_R C_G C_B];
            C_=C_';
           
            
            pathresult = sprintf('%s/%s_%02d_%02d%s',savepath,folder_set{i},uint8(j),uint8(l),savetype);
            mesh = genMesh(vertex,grid);
            save_name = sprintf('%s%s%s.ply',pathresult,'_',num2str(l));
            saveMeshAsPly_still(save_name,vertex, mesh, [], C_);
        end
    end
end